var data = require('./city.json')
var city = data.citys
module.exports = {
  devServer: {
    before(app){
      app.get('/data/city',function(req,res){
        res.json({data:city})
      })
    },
    proxy: {
      "/api": {
        target: "https://www.tianqiapi.com",
        changeOrigin: true
      }
    }
  },
};

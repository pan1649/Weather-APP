<template>
  <div id="app">
    <router-view
      :oneday="oneday"
      :days="days"
      :city="city"
      @appChange="appChange"
      :list="list"
      @appdel="appdel"
    />
  </div>
</template>

<script>
export default {
  data: () => ({
    oneday: [],
    days: [],
    city: "广州",
    list: [
      { city: "广州", id: 1 },
      { city: "深圳", id: 2 },
      { city: "珠海", id: 3 }
    ]
  }),
  methods: {
    async getweather() {
      let res = await this.$axios(
        `/api/?appid=64851857&appsecret=sq1m29k7&version=v1&city=${this.city}`
      );
      this.oneday = [res.data.data[0]];
      this.days = res.data.data;
      // console.log(this.oneday);
      // console.log(this.days);
    },
    appChange(data) {
      console.log("触发appChange");
      console.log(data);
      this.city = data;

      let flag = false;
      for (var i in this.list) {
        if (this.list[i].city == data) {
          //z这里一定要写找相同的，不然如果你找的不同的，他可能和第一个比不同，第二个相同了，你就不能添加进去的。
          flag = true; //如果找到相同的让flag为true
        }
      } //循环结束。
      if (flag == false) {
        this.list.push({ city: data, id: new Date });
      }

      console.log(this.oneday)
    },
    appdel(id) {
      console.log("触发appdel");
      this.list = this.list.filter(item => item.id !== id);
    }
  },
  created() {
    this.$router.push({ path: "/" });
  },
  mounted() {
    this.getweather();
  },
  watch: {
    city() {
      this.getweather();
    }
  }
};
</script>

<style lang="scss">
</style>

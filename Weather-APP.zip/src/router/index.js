import Vue from "vue";
import VueRouter from "vue-router";
import Home from "../views/Home.vue";
import Swiper from "../views/Swiper.vue";
import Banner from "../views/Banner.vue";
import LineChart from "../views/LineChart.vue";
import City from "../views/City.vue";
import Search from "../views/Search.vue";


Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "Swiper",
    component: Swiper
  },
  {
    path: "/Home",
    name: "Home",
    component: Home
  },
  {
    path: "/Banner",
    name: "Banner",
    component: Banner
  },
  {
    path: "/LineChart",
    name: "LineChart",
    component: LineChart
  },
  {
    path: "/City",
    name: "City",
    component: City
  },
  {
    path: "/Search",
    name: "Search",
    component: Search
  },
 
  // {
  //   path: "/about",
  //   name: "about",
  //   // route level code-splitting
  //   // this generates a separate chunk (about.[hash].js) for this route
  //   // which is lazy-loaded when the route is visited.
  //   component: () =>
  //     import(/* webpackChunkName: "about" */ "../views/About.vue")
  // }
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
});



export default router;

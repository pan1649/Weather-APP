<template>
  <div class="homebox">
    <header ref="header">
      <div class="header">
        <div>{{city}}</div>
        <div class="iconfont icon-ziyuan" @click="goSearch()"></div>
      </div>
    </header>

    <nav>
      <div class="navbg" v-for="(item,a) in oneday" :key="a+1">
        <img :src="require(`../assets/img/${item.wea_img}.png`)" />
      </div>
      <div class="celsiu" v-for="(item,b) in oneday" :key="b+2">
        <div class="celsius">{{item.tem}}</div>
        <div class="celsius-text">
          <div class="celsius-text-box">
            <span>天气情况</span>
            <span>:</span>
            <span>{{item.wea}}</span>
          </div>
          <div class="celsius-text-box">
            <span>空气质量</span>
            <span>:</span>
            <span>{{item.air}}</span>
          </div>
          <div class="celsius-text-box">
            <span>空气质量等级</span>
            <span>:</span>
            <span>{{item.air_level}}</span>
          </div>
        </div>
      </div>
    </nav>

    <div class="ulbox" ref="hoursScroll">
      <ul
        class="ul"
        v-for="(item,c) in oneday"
        :key="c+3"
        :style="{width:oneday[0].hours.length * 86 + 'px'}"
      >
        <li class="li" v-for="(value,d) in item.hours" :key="d+4">
          <div>{{value.day}}</div>
          <div>{{value.wea}}</div>
          <div>{{value.tem}}</div>
          <div class="text">{{value.win}}</div>
          <div class="text">{{value.win_speed}}</div>
        </li>
      </ul>
    </div>

    <div class="link"></div>

    <div class="daysbox" ref="daysScroll">
      <div class="days" :style="{height:days.length * 40 + 'px'}">
        <ul v-for="(item,e) in days" :key="e+5">
          <li>
            <div class="li-left">{{item.day}}</div>
            <div class="li-center">
              <img :src="require(`../assets/img/${item.wea_img}.png`)" />
              <span>{{item.wea}}</span>
            </div>
            <div class="li-right">
              {{item.tem2}}
              <span>~</span>
              {{item.tem1}}
            </div>
          </li>
        </ul>
      </div>
    </div>

    <div class="link"></div>
    <router-link tag="div" to="/LineChart" class="linechart">
      <span class="line-left">未来7天气温折线图</span>
      <span class="line-right">></span>
    </router-link>

    <div class="link"></div>

    <div class="advise">
      <ul>
        <li v-for="(item,f) in oneday[0].index" :key="f+6">
          <div v-if="( f === 0 )" class="iconfont icon-taiyang"></div>
          <div v-if="( f === 1 )" class="iconfont icon-19"></div>
          <div v-if="( f === 2 )" class="iconfont icon-navicon-jkgy"></div>
          <div v-if="( f === 3 )" class="iconfont icon-yifu"></div>
          <div v-if="( f === 4 )" class="iconfont icon-Car"></div>
          <div v-if="( f === 5 )" class="iconfont icon-kongqizhiliang"></div>
          <div class="title">{{item.title}}</div>
          <div class="level">{{item.level}}</div>
          <div class="desc">{{item.desc}}</div>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import BScroll from "better-scroll";
export default {
  props: {
    city: String,
    oneday: Array,
    days: Array
  },
  data: function() {
    return {
      myday: "",
      mydays: ""
    };
  },
  mounted() {
    //重新赋值可以触发watch
    this.myday = this.oneday;
    this.mydays = this.days;
    window.addEventListener("scroll", this.handleScroll);
  },
  computed: {},
  methods: {
    goSearch() {
      this.$router.push({ path: "/City" });
    },
    handleScroll() {
      var t = document.body.scrollTop || document.documentElement.scrollTop;
      var h = 200;
      var opacity = 0;

      if (t > h) {
        opacity = 1;
      } else {
        opacity = (t / h) * 1;
      }
      let header = this.$refs.header;
      header.style.backgroundColor = "rgba(255, 253, 255," + opacity + ")";
      // console.log(t, h, opacity);
    }
  },
  beforeDestroy() {
    window.removeEventListener("scroll", this.handleScroll);
  },
  watch: {
    myday(newVal) {
      this.$nextTick(() => {
        if (!this.sellerScroll) {
          if (newVal) {
            console.log("触发hoursScroll");
            new BScroll(this.$refs.hoursScroll, {
              scrollX: true
            });
          }
        } else {
          this.sellerScroll.refresh();
        }
      });
    },
    mydays(newVal) {
      this.$nextTick(() => {
        if (!this.sellerScroll) {
          if (newVal) {
            console.log("触发daysScroll");
            new BScroll(this.$refs.daysScroll, {
              scrollX: true
            });
          }
        } else {
          this.sellerScroll.refresh();
        }
      });
    }
  }
};
</script>
<style lang="scss" scoped>
.homebox {
  background: rgb(220, 232, 255);
  background: linear-gradient(
    135deg,
    rgba(220, 232, 255, 0.4) 0%,
    rgba(243, 249, 243, 0.4) 100%
  );
}
.linechart {
  line-height: 40px;
  height: 40px;
  padding: 0 8px;
  box-sizing: border-box;
  display: flex;
  justify-content: space-between;

  .line-left {
    font-size: 14px;
  }
  .line-right {
    font-size: 20px;
  }
}
.link {
  height: 6px;
  background: rgba(255, 255, 251, 1);
}

header {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  z-index: 999;
  color: rgba(148, 187, 233, 1);
  .header {
    display: flex;
    justify-content: space-between;
    height: 40px;
    padding: 5px 8px;
    line-height: 30px;
    font-size: 22px;
    box-sizing: border-box;
    .icon-ziyuan {
      font-size: 24px;
    }
  }
}

nav {
  width: 100%;
  box-sizing: border-box;
  padding-bottom: 20px;
  .navbg {
    height: 250px;
    position: relative;

    img {
      position: absolute;
      right: 30px;
      width: 70px;
      top: 80px;
      background-size: contain;
    }
  }
  .celsiu {
    padding: 0 8px;
    width: 100%;
    display: flex;
    justify-content: flex-start;
    box-sizing: border-box;

    .celsius {
      flex: 0 0 20%;
      height: 90px;
      font-size: 66px;
      line-height: 90px;
      vertical-align: left;
      color: rgba(148, 187, 233, 1);
      margin-right: 5px;
    }
    .celsius-text-box {
      flex: auto;
      height: 30px;
      line-height: 30px;
      font-size: 14px;
      color: rgba(148, 187, 233, 1);
      span {
        margin-left: 10px;
      }
    }
  }
}

.ulbox {
  overflow: hidden;
  box-sizing: border-box;
  .ul {
    padding: 20px 8px;
    display: flex;
    justify-content: space-between;
    .li {
      flex: 0 0 86px;
      text-align: center;
      font-size: 14px;
      color: rgba(148, 187, 233, 1);
      div {
        height: 24px;
        line-height: 24px;
      }
    }
  }
}

.daysbox {
  height: 200px;
  overflow: hidden;
  margin: 20px 8px;
  box-sizing: border-box;
}
.daysbox {
  height: 200px;
  overflow: hidden;
  margin: 20px 8px;
  box-sizing: border-box;
  .days {
    width: 100%;
    box-sizing: border-box;
    li {
      width: 100%;
      display: flex;
      justify-content: space-between;
      height: 40px;
      line-height: 40px;
      font-size: 14px;
      .li-left {
        text-align: left;
        flex: 1.2;
      }
      .li-center {
        text-align: left;
        color: #999;
        flex: 1.2;
        img {
          width: 22px;
          transform: translateY(6px);
        }
        span {
          margin-left: 4px;
        }
      }
      .li-right {
        flex: 1;
        text-align: right;
        span {
          color: #999;
        }
      }
    }
  }
}

.advise {
  width: 100%;
  padding: 10px 8px;
  box-sizing: border-box;
  ul {
    width: 100%;
    overflow: hidden;
    li {
      width: 33.333%;
      float: left;
      overflow: hidden;
      box-sizing: border-box;
      border-right: 1px solid #ccc;
      border-bottom: 1px solid #ccc;
      padding: 5px 0px;
      min-height: 166px;
      &:nth-child(3) {
        border-right: none;
      }
      &:nth-child(6) {
        border-right: none;
        border-bottom: none;
      }
      &:nth-child(5) {
        border-bottom: none;
      }
      &:nth-child(4) {
        border-bottom: none;
      }
      div {
        text-align: center;
      }
      .title {
        font-size: 12px;
        height: 28px;
        font-weight: bold;
        line-height: 28px;
        padding: 0 2px;
      }
      .level {
        font-size: 12px;
        height: 26px;
        line-height: 26px;
      }
      .desc {
        font-size: 12px;
        color: #666;
        height: 64px;
        padding: 0 4px;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 3;
        overflow: hidden;
      }
    }
  }
}

.icon-Car,
.icon-kongqizhiliang,
.icon-yifu,
.icon-navicon-jkgy,
.icon-taiyang,
.icon-19 {
  font-size: 34px;
  font-weight: 600;
}
.icon-Car {
  color: #1296db;
}
.icon-kongqizhiliang {
  color: #00cd00;
}
.icon-yifu {
  color: rgb(130, 166, 243);
}
.icon-navicon-jkgy {
  color: rgb(118, 243, 135);
}

.icon-taiyang {
  color: #f7941d;
}

.icon-19 {
  color: #f7941d;
}
</style>
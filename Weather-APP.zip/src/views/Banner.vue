<template>
  <div>
    <img
      src="../assets/bg/timg.jpg"
    />
    <span @click="go()" class="skip">{{ num }}S/跳过</span>
  </div>
</template>

<script>
export default {
  data: () => ({
    num: 3,
    timer: null
  }),
  methods: {
    go() {
      this.$router.push({ path: "/Home" });
    }
  },
  created() {
    this.timer = setInterval(() => {
      if (this.num == 0) {
        this.$router.push({ path: "/Home" });
      } else {
        this.num--;
      }
    }, 1000);
  },
  beforeDestroy() {
    //页面跳转前先摧毁定时器
    clearInterval(this.timer);
  }
};
</script>
<style lang="scss" scoped>
.skip {
  position: fixed;
  padding: 2px;
  top: 5px;
  right: 5px;
  border: 1px solid rgba(255, 255, 255, 0.4);
  border-radius: 5px 10px;
  font-size: 12px;
  background-color: rgba(255, 255, 255, 0.1);
  color: #fff;
}
img {
  width: 100%;
  height: 100%;
  background-size: contain;
}
</style>
<template>
  <div>
    <!-- Swiper -->
    <div class="swiper-container">
      <div class="swiper-wrapper">
        <div class="swiper-slide">
          <img class="animated fadeInRighr" src="../assets/bg/bg1.png"/>
        </div>
        <div class="swiper-slide">
          <img class="animated fadeInRighr" src="../assets/bg/bg2.png"/>
        </div>
        <div class="swiper-slide">
          <img class="animated fadeInRighr" src="../assets/bg/bg3.png"/>
          <button @click="go()" class="animated fadeInUp delay-0.5s">立即体验</button>
        </div>
      </div>
      <!-- Add Pagination -->
      <div class="swiper-pagination"></div>
    </div>
  </div>
</template>

<script>
import "animate.css";
import Swiper from "swiper";
export default {
  data() {
    return {};
  },
  methods: {
    go() {
      localStorage.fist = true;
      this.$router.push({ path: "/Home" });
    }
  },
  created() {
    if (localStorage.fist) {
      this.$router.push({ path: "/Banner" });
    } else {
      localStorage.fist = true;
    }
  },
  mounted() {
    new Swiper(".swiper-container", {
      pagination: {
        el: ".swiper-pagination"
      }
    });
  }
};
</script>

<style lang="scss" scoped>
.swiper-container {
  position: fixed;
  top: 0px;
  left: 0px;
  width: 100%;
  height: 100%;
}
.swiper-wrapper {
  width: 100%;
  height: 100%;
}
.swiper-slide {
  width: 100%;
  height: 100%;
  text-align: center;
  display: block;
  overflow: hidden;
  // background-color: red;
  img {
    width: 100%;
    height: 100%;
  }
  h3 {
    color: #808080;
    z-index: 10000;
  }
}
button {
  width: 200px;
  height: 45px;
  line-height: 45px;
  border: 1px solid #e6e9e7;
  background: rgba(250, 246, 246, 0.5);
  position: absolute;
  left: 0px;
  right: 0px;
  bottom: 30px;
  margin: 0 auto;
  font-size: 20px;
  color: #666;
}

</style>

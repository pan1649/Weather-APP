<template>
  <div class="mainbox">
    <div class="icon">
      <span class="iconfont icon-zuojiantou" @click="go()"></span>
      <span>城市选择</span>
    </div>

    <div v-for="(item,i) in list" :key="i+1">
      <div class="citys">
        <div class="city" @click="changeCity(item.city)">{{item.city}}</div>
        <div class="iconfont icon-chenghao1" @click="del(item.id)"></div>
      </div>
    </div>

    <div class="btn">
      <button @click="goSearch()">添加城市</button>
    </div>
  </div>
</template>
<script>
export default {
  data: function() {
    return {
      mycity: this.city
    };
  },
  props: {
    city: String,
    list: Array
  },
  methods: {
    go() {
      this.$router.go(-1);
    },
    goSearch() {
      this.$router.push({ path: "/Search" });
    },
    changeCity(data) {
      console.log(data);
      this.$emit("appChange", data);
      this.$router.push({ path: "/Home" });
    },
    del(id) {
      console.log("chu发  del");
      this.$emit("appdel", id);
    }
  }
};
</script>
<style lang="scss" scoped>
.mainbox {
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  background: rgb(238, 174, 202);
  background: linear-gradient(
    184deg,
    rgba(148, 187, 233, 0.2) 0%,
    rgba(238, 174, 202, 0.2) 1000%
  );

  .icon {
    height: 40px;
    line-height: 40px;
    text-align: center;
    position: relative;
    border-bottom: 1px solid #ccc;
    .icon-zuojiantou {
      position: absolute;
      left: 10px;
    }
  }

  .citys {
    padding: 5px 40px;
    width: 100%;
    display: flex;
    justify-content: space-between;
    box-sizing: border-box;
    border-bottom: 1px solid #999;
    .city {
      width: 80%;
      height: 40px;
      line-height: 40px;
    }
    .icon-chenghao1 {
      width: 20%;
      height: 40px;
      line-height: 40px;
      text-align: right;
    }
  }
}
.btn {
  margin-top: 20px;
  text-align: center;
  button {
    width: 150px;
    outline: none;
    border: none;
    padding: 5px 10px;
    border-radius: 10px;
    background-color: rgb(142, 142, 241);
    color: white;
    height: 45px;
    box-sizing: border-box;
    font-size: 16px;
  }
}
</style>
<template>
  <div class="mainbox">
    <div class="icon">
      <span class="iconfont icon-zuojiantou" @click="go()"></span>
      <span>城市搜索</span>
    </div>
    <div class="title">去除省,市,区,镇,可单独填写一个地区</div>
    <div class="title">例如广州市番禺区=== 番禺</div>
    <div class="ipnutbox">
      <div class="input">
        <input type="text" v-model="key" placeholder />
      </div>
      <div class="iconfont icon-chenghao1" @click="del()"></div>
    </div>
    <div class="title" v-show="key">找到以下包含{{key}}数据</div>
    <div class="ulbox" ref="cityScroll">
      <ul class="ul" :style="{height:city.length * 30 + 'px'}">
        <li class="li" v-for="(item,i) in todolist(key) " :key="i" @click="select(item.cityZh)">
          <div>{{item.cityZh}}-{{item.leaderZh}}-{{item.provinceZh}}</div>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import BScroll from "better-scroll";
export default {
  data: function() {
    return {
      city: "",
      key: "",
      list: [
        {
          id: "101010100",
          cityEn: "beijing",
          cityZh: "北京",
          provinceEn: "beijing",
          provinceZh: "北京",
          leaderEn: "beijing",
          leaderZh: "北京",
          lat: "39.904989",
          lon: "116.405285"
        },
        {
          id: "101010200",
          cityEn: "haidian",
          cityZh: "海淀",
          provinceEn: "beijing",
          provinceZh: "北京",
          leaderEn: "beijing",
          leaderZh: "北京",
          lat: "39.956074",
          lon: "116.310316"
        }
      ]
    };
  },
  methods: {
    go() {
      this.$router.go(-1);
    },
    async getcity() {
      let res = await this.$axios("/data/city");
      this.city = res.data.data;
      console.log(this.city);
    },
    del() {
      this.key = null;
    },
    select(data) {
      console.log(data);
      this.$emit("appChange", data);
      this.$router.push({ path: "/Home" });
    },
    todolist(key) {
      if (this.city.length === 0) {
        return false;
      } else {
        return this.city.filter(item => {
          if (
            item.cityZh.includes(key) ||
            item.provinceZh.includes(key) ||
            item.leaderZh.includes(key)
          ) {
            return item;
          }
        });
      }
    }
  },
  mounted() {
    this.getcity();
  },
  watch: {
    city(newVal) {
      this.$nextTick(() => {
        if (!this.sellerScroll) {
          if (newVal) {
            console.log("触发cityScroll");
            new BScroll(this.$refs.cityScroll, {
              scrollY: true,
              click: true //开启点击事件
            });
          }
        } else {
          this.sellerScroll.refresh();
        }
      });
    }
  }
};
</script>
<style lang="scss" scoped>
.title {
  text-align: center;
  height: 30px;
}
.mainbox {
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  background: rgb(238, 174, 202);
  background: linear-gradient(
    184deg,
    rgba(148, 187, 233, 0.2) 0%,
    rgba(238, 174, 202, 0.2) 1000%
  );

  .icon {
    height: 40px;
    line-height: 40px;
    text-align: center;
    position: relative;
    border-bottom: 1px solid #ccc;
    .icon-zuojiantou {
      position: absolute;
      left: 10px;
    }
  }

  .citys {
    padding: 5px 40px;
    width: 100%;
    display: flex;
    justify-content: space-between;
    box-sizing: border-box;
    // border-bottom: 1px solid #999;
    .city {
      width: 80%;
      height: 40px;
      line-height: 40px;
    }
    .icon-chenghao1 {
      width: 20%;
      height: 40px;
      line-height: 40px;
      text-align: center;
    }
  }
  .ipnutbox {
    width: 100%;
    display: flex;
    justify-content: space-between;
    height: 40px;
    line-height: 40px;
    box-sizing: border-box;
    border: 1px solid #ccc;
    .input {
      flex: auto;
      input {
        width: 100%;
        outline: none;
        border: none;
        height: 36px;
        vertical-align: top;
        font-size: 16px;
        text-indent: 2em;
      }
    }
    .icon-chenghao1 {
      flex: 0 0 40px;
      text-align: center;
    }
  }
  .ulbox {
    margin-top: 30px;
    width: 100%;
    height: 400px;
    overflow: hidden;
    .ul {
      width: 100%;
      .li {
        width: 100%;
        height: 30px;
        line-height: 30px;
        text-align: center;
        border-bottom: 1px solid #333;
      }
    }
  }
}
</style>
<template>
  <div class="mainbox">
    <div class="icon">
      <span class="iconfont icon-zuojiantou" @click="go()"></span>
      <span>未来七天天气折线图</span>
    </div>
    <div id="main" class="main"></div>
  </div>
</template>

<script>
export default {
  data: function() {
    return {
      mycity: "",
      line: [],
      week: [],
      tem1: [],
      tem2: []
    };
  },
  props: {
    city: String
  },
  methods: {
    go(){
      this.$router.go(-1);
    },
    async getLine() {
      let res = await this.$axios(
        `/api/?appid=64851857&appsecret=sq1m29k7&version=v1&city=${this.mycity}`
      );
      this.line = res.data.data;
      console.log(this.line);
    },
    rander() {
      for (var i = 0; i < this.line.length; i++) {
        this.week.push(this.line[i].week);
        this.tem1.push(
          (this.line[i].tem1 = this.line[i].tem1.substring(
            0,
            this.line[i].tem1.length - 1
          ))
        );
        this.tem2.push(
          (this.line[i].tem2 = this.line[i].tem2.substring(
            0,
            this.line[i].tem2.length - 1
          ))
        );
      }
      console.log(this.week, this.tem1, this.tem2);

      // 基于准备好的dom，初始化echarts实例
      var myChart = this.$echarts.init(document.getElementById("main"));

      // 指定图表的配置项和数据
      var option = {
        tooltip: {
          trigger: "axis"
        },
        legend: {
          data: ["最高气温", "最低气温"]
        },
        toolbox: {
          show: true
        },
        xAxis: {
          type: "category",
          boundaryGap: false,
          data: this.week
        },
        yAxis: {
          type: "value",
          axisLabel: {
            formatter: "{value} °C"
          }
        },
        series: [
          {
            name: "最高气温",
            type: "line",
            data: this.tem1,
            itemStyle: { normal: { label: { show: true, position: "top" } } }
          },
          {
            name: "最低气温",
            type: "line",
            data: this.tem2,
            itemStyle: { normal: { label: { show: true, position: "top" } } }
          }
        ]
      };
      myChart.setOption(option);
    }
  },
  mounted() {
    this.mycity = this.city;
    this.getLine();
  },
  watch: {
    line() {
      this.rander();
    }
  }
};
</script>
<style lang="scss" scoped>
.mainbox {
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  background: rgb(238, 174, 202);
  background: linear-gradient(
    184deg,
    rgba(148, 187, 233, .2) 0%,
     rgba(238, 174, 202, .2) 1000%,
  );
  
  .icon {
    height: 40px;
    line-height: 40px;
    text-align: center;
    position: relative;
    border-bottom: 1px solid #ccc;
    .icon-zuojiantou {
      position: absolute;
      left: 10px
    }
  }
  .main {
    margin-top: 30px;
    padding-left: 5px;
    box-sizing: border-box;
    width: 100%;
    height: 400px;
  }
}
</style>
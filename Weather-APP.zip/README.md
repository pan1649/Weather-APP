# weather

## Project setup
```
npm install 
下载 node_modules 依赖包
```

### Compiles and hot-reloads for development
```
npm run serve
启动项目
```


